CREATE VIEW sales_type_store AS
SELECT p.transaction_id_purchases, p.card_id_purchases, p.product_id_purchases, p.quantity, h.product_id_has, h.store_id_has  
FROM purchases AS p, has AS h, product AS q
WHERE p.product_id_purchases = h.product_id_has
      AND h.product_id_has = q.product_id
      ORDER BY h.store_id_has, h.product_id_has;

CREATE VIEW who_is_the_customer AS 
SELECT DISTINCT card_id, first_name, second_name, last_name, marital_status, sex, phone_number;
FROM customer ;

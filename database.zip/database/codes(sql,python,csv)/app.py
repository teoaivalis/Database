from flask import Flask, render_template, request, redirect
from flask_mysqldb import MySQL
import yaml
import inserts
import updates
import delete
from datetime import datetime

app = Flask(__name__, static_url_path='/static')

# Configure db
db = yaml.load(open('db.yaml'))
app.config['MYSQL_HOST'] = db['mysql_host']
app.config['MYSQL_USER'] = db['mysql_user']
app.config['MYSQL_PASSWORD'] = db['mysql_password']
app.config['MYSQL_DB'] = db['mysql_db']

mysql = MySQL(app)

@app.route('/')
def home():
    return render_template('Home.html')

@app.route("/PurchasesPerStore",methods=['GET', 'POST'])
def PurchasesPerStore():
    if request.method == 'POST':
        # Fetch form data
        Details = request.form
        City_of_Store = Details['City_of_Store']
        Street_Name_of_Store = Details['Street_Name_of_Store']
        Date_of_Transaction = Details['Date_of_Transaction']
        Total_Amount_of_Products = Details['Total_Amount_of_Products']
        Total_Cost = Details['Total_Cost']
        Means_of_Payment = Details['Means_of_Payment']
        query = """SELECT distinct s.city,s.street_name,c.first_name,c.last_name,t.date_of_transaction,t.means_of_payment,t.total_cost,t.total_amount_of_products,pr.product_name

        FROM purchases as p
        LEFT JOIN transaction as t
        ON p.transaction_id_purchases=t.transaction_id
        INNER JOIN product AS pr
        ON pr.product_id=p.product_id_purchases
        INNER JOIN customer AS c
        ON c.card_id=p.card_id_purchases
        INNER JOIN store AS s
        ON s.store_id=p.store_id_purchases
        INNER JOIN contains as con
        ON con.store_id_contains=s.store_id

        WHERE  """
        A = False;
        if City_of_Store != "":
            query += "s.city LIKE '" + City_of_Store + "'"
            A = True
        if Street_Name_of_Store != "":
            if A == True:
                query += " AND "
            query += "s.street_name LIKE '" + Street_Name_of_Store + "'"
            A = True
        if Date_of_Transaction != "":
            if A == True:
                query += " AND "
            query += "t.date_of_transaction = '" + Date_of_Transaction + "'"
            A = True
        if Means_of_Payment != "":
            if A == True:
                query += " AND "
            query += "t.means_of_payment LIKE '" + Means_of_Payment + "'"
            A = True
        if Total_Cost != "-1":
            if A == True:
                query += " AND "
            query += "t.total_cost = " + Total_Cost + ""
            A = True
        if Total_Amount_of_Products != "-1":
            if A == True:
                query += " AND "
            query += "t.total_amount_of_products  = '" + Total_Amount_of_Products + "'"
            A = True
        query += "order by t.total_cost;"
        print(query)
        cur = mysql.connection.cursor()
        resultValue = cur.execute(query)
        if resultValue > 0:
            userDetails = cur.fetchall()
        if cur.rowcount == 0 :
            return render_template("Error.html")
        else:
            return render_template("PurchasesPerStoreOutput.html",userDetails=userDetails)
    return render_template("PurchasesPerStore.html")


@app.route('/View')
def View():
    return render_template("View.html")

@app.route('/CustomerView')
def CustomerView():
    cur = mysql.connection.cursor()
    query = """SELECT * FROM who_is_the_customer;"""
    resultValue = cur.execute(query)
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template('CustomerView.html',userDetails = userDetails)

@app.route('/Example')
def Example():
    return render_template("Example.html")

@app.route('/Special1')
def Special1():
    cur = mysql.connection.cursor()
    query = """select c.first_name, c.last_name, d.total_cost_of_customer_purchases
                from customer as c, customer_points as d
                where d.total_cost_of_customer_purchases > 100 and d.card_id_points = c.card_id and DATE(c.birthday) BETWEEN '1000-01-01' AND '1999-12-30'"""
    resultValue = cur.execute(query)
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template('Special1.html',userDetails = userDetails)

@app.route('/Special2')
def Special2():
    cur = mysql.connection.cursor()
    query = """select distinct corridor, p.product_name
                from has as h, product as p
                where h.product_id_has = p.product_id and p.current_price > 40
                order by corridor;"""
    resultValue = cur.execute(query)
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template('Special2.html',userDetails = userDetails)

@app.route('/ProductHistoryOption',methods=['GET', 'POST'])
def ProductHistoryOption():
    if request.method == 'POST':
        ProductPriceDetails = request.form
        product_id = ProductPriceDetails['product_id']
        cur = mysql.connection.cursor()
        query = """ select u.product_id_used, p.date_of_change, p.past_price_of_product
                    from past_prices AS p,used_to_cost AS u
                    where p.date_of_change = u.date_of_change_used and u.product_id_used = """ + product_id + """ ORDER BY p.date_of_change DESC;"""
        resultValue = cur.execute(query)
        if resultValue > 0:
            userDetails = cur.fetchall()
        if cur.rowcount == 0 :
            return render_template("Error.html")
        else:
            return render_template('ProductHistory.html',userDetails = userDetails)
    return render_template('ProductHistoryOption.html')

@app.route("/UpdateProductPrice",methods=['GET', 'POST'])
def UpdateProductPrice():
    if request.method == 'POST':
        # Fetch form data
        ProductPriceDetails = request.form
        product_id = ProductPriceDetails['product_id']
        new_price = ProductPriceDetails['current_price']
        cur = mysql.connection.cursor()

        query = "SELECT current_price from product where product_id = " + str(product_id)
        resultValue = cur.execute(query)
        resultValue = cur.fetchall()[0][0]
        print("resultValue = ", resultValue)
        formatted_date = datetime.today().strftime('%Y-%m-%d')
        inserts.insert_used_to_cost(product_id,formatted_date)
        inserts.insert_past_prices(formatted_date,resultValue)
        updates.update_product(product_id,"",new_price,"","")
        cur = mysql.connection.cursor()
        query = """ select u.product_id_used, p.date_of_change, p.past_price_of_product
                    from past_prices AS p,used_to_cost AS u
                    where p.date_of_change = u.date_of_change_used and u.product_id_used = """ + product_id + """ ORDER BY p.date_of_change DESC;"""
        resultValue = cur.execute(query)
        if resultValue > 0:
            userDetails = cur.fetchall()
        if cur.rowcount == 0 :
            return render_template("Error.html")
        else:
            return render_template('ProductHistory.html',userDetails = userDetails)
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * from product order by current_price")
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template("UpdateProductPrice.html",userDetails=userDetails)
    return render_template("Error.html")

@app.route('/ProductHistory')
def ProductHistory():
    cur = mysql.connection.cursor()
    query = """ select u.product_id_used, p.date_of_change, p.past_price_of_product
                from past_prices AS p,used_to_cost AS u
                where p.date_of_change = u.date_of_change_used and u.product_id_used = """ + product_id + """ ORDER BY p.date_of_change DESC;"""
    resultValue = cur.execute(query)
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template('ProductHistory.html',userDetails = userDetails)

@app.route('/SalesPerCategoryView')
def SalesPerCategoryView():
    cur = mysql.connection.cursor()
    query = """SELECT * FROM sales_type_store;"""
    resultValue = cur.execute(query)
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template('SalesPerCategoryView.html',userDetails = userDetails)


@app.route('/Error')
def Error():
    return render_template('Error.html')

@app.route("/Edit")
def Edit():
    return render_template("Edit.html")

@app.route("/InsertCustomers",methods=['GET', 'POST'])
def InsertCustomers():
    if request.method == 'POST':
        # Fetch form data
        Details = request.form
        Card_id = Details['Card_ID']
        Customers_city = Details['Customers_city']
        customers_postal_code = Details['customers_postal_code']
        customers_street_name = Details['customers_street_name']
        customers_street_number = Details['customers_street_number']
        first_name = Details['first_name']
        second_name = Details['second_name']
        last_name = Details['last_name']
        marital_status = Details['marital_status']
        number_of_kids = Details['number_of_kids']
        sex = Details['sex']
        phone_number = Details['phone_number']
        birthday = Details['birthday']
        inserts.insert_customer(Card_id,Customers_city,customers_postal_code,customers_street_name,customers_street_number,first_name,second_name,last_name,marital_status,number_of_kids,sex,phone_number,birthday)
        return redirect('/Customers')
    return render_template("InsertCustomers.html")

@app.route("/InsertStores",methods=['GET', 'POST'])
def InsertStores():
    if request.method == 'POST':
        # Fetch form data
        Details = request.form
        store_id = Details['store_id']
        square_meters = Details['square_meters']
        opening_hour = Details['opening_hour']
        closing_hour = Details['closing_hour']
        city = Details['city']
        postal_code = Details['postal_code']
        street_name = Details['street_name']
        street_number = Details['street_number']
        inserts.insert_store(store_id,square_meters, opening_hour, closing_hour, city, postal_code, street_name,street_number)
        return redirect('/Stores')
    return render_template("InsertStores.html")

@app.route("/InsertProducts",methods=['GET', 'POST'])
def InsertProducts():
    if request.method == 'POST':
        # Fetch form data
        Details = request.form
        product_id = Details['product_id']
        product_name = Details['product_name']
        current_price = Details['current_price']
        special_store_label = Details['special_store_label']
        inserts.insert_product(product_id,product_name,current_price,special_store_label)
        return redirect('/Products')
    return render_template("InsertProducts.html")

@app.route("/UpdateCustomers",methods=['GET', 'POST'])
def UpdateCustomers():
    if request.method == 'POST':
        # Fetch form data
        Details = request.form
        card_id = Details['card_id']
        customers_city = Details['customers_city']
        customers_postal_code = Details['customers_postal_code']
        customers_street_name = Details['customers_street_name']
        customers_street_number = Details['customers_street_number']
        first_name = Details['first_name']
        second_name = Details['second_name']
        last_name = Details['last_name']
        marital_status = Details['marital_status']
        number_of_kids = Details['number_of_kids']
        sex = Details['sex']
        phone_number = Details['phone_number']
        birthday = Details['birthday']
        updates.update_customer (card_id, customers_city, customers_postal_code, customers_street_name, customers_street_number, first_name, second_name, last_name , marital_status, number_of_kids , sex, phone_number, birthday)
        return redirect('/Customers')
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * from customer")
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template("UpdateCustomers.html",userDetails=userDetails)
    return render_template("Error.html")

@app.route("/UpdateStores",methods=['GET', 'POST'])
def UpdateStores():
    if request.method == 'POST':
        # Fetch form data
        Details = request.form
        store_id = Details['store_id']
        square_meters = Details['square_meters']
        opening_hour = Details['opening_hour']
        closing_hour = Details['closing_hour']
        city = Details['city']
        postal_code = Details['postal_code']
        street_name = Details['street_name']
        street_number = Details['street_number']
        updates.update_store (store_id, square_meters, opening_hour, closing_hour, city, postal_code, street_name, street_number)
        return redirect('/Stores')
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * from store")
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template("UpdateStores.html",userDetails=userDetails)
    return render_template("Error.html")

@app.route("/UpdateProducts",methods=['GET', 'POST'])
def UpdateProducts():
    if request.method == 'POST':
        # Fetch form data
        Details = request.form
        product_id = Details['product_id']
        product_name = Details['product_name']
        current_price = Details['current_price']
        special_store_label = Details['special_store_label']
        updates.update_product(product_id, product_name, current_price , special_store_label , condition= '')
        return redirect('/Products')
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * from product")
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template("UpdateProducts.html",userDetails=userDetails)
    return render_template("Error.html")

@app.route("/DeleteCustomers",methods=['GET', 'POST'])
def DeleteCustomers():
    if request.method == 'POST':
        # Fetch form data
        Details = request.form
        card_id = Details['card_id']
        delete.delete_customer(card_id ,condition = '')
        return redirect('/Customers')
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * from customer")
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template("DeleteCustomers.html",userDetails=userDetails)
    return render_template("Error.html")

@app.route("/DeleteStores",methods=['GET', 'POST'])
def DeleteStores():
    if request.method == 'POST':
        # Fetch form data
        Details = request.form
        store_id = Details['store_id']
        delete.delete_store(store_id , condition = '')
        return redirect('/Stores')
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * from store")
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template("DeleteStores.html",userDetails=userDetails)
    return render_template("Error.html")

@app.route("/DeleteProducts",methods=['GET', 'POST'])
def DeleteProducts():
    if request.method == 'POST':
        # Fetch form data
        Details = request.form
        product_id = Details['product_id']
        delete.delete_product (product_id ,condition = '')
        return redirect('/Products')
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * from product")
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template("DeleteProducts.html",userDetails=userDetails)
    return render_template("Error.html")

@app.route("/Customers")
def Publishers():
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * FROM customer")
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template("Customers.html",userDetails=userDetails)
    return render_template("Error.html")

@app.route("/Stores")
def Stores():
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * FROM store")
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template("Stores.html",userDetails=userDetails)
    return render_template("Error.html")

@app.route("/Products")
def Products():
    cur = mysql.connection.cursor()
    resultValue = cur.execute("SELECT * FROM product")
    if resultValue > 0:
        userDetails = cur.fetchall()
    if cur.rowcount == 0 :
        return render_template("Error.html")
    else:
        return render_template("Products.html",userDetails=userDetails)
    return render_template("Error.html")

if __name__ == '__main__':
    app.run(debug=True)

def insert_consists(product_id_consists,type_id_consists):
    query = "INSERT INTO consists VALUES(%s,%s,%s)"
	args = (product_id_consists,type_id_consists)
	try:
		db_config = read_db_config()
		conn = MySQLConnection(**db_config)

		cursor = conn.cursor()
		cursor.execute(query, args)

		if cursor.lastrowid:
			print('done')
		else:
			print('last insert id not found')

		conn.commit()
	except Error as error:
		print(error)

	finally:
		cursor.close()
		conn.close()

















def insert_contains(store_id_contains,type_id_contains):
	query = "INSERT INTO contains VALUES(%s,%s)"
	args = (store_id_contains,type_id_contains)
	try:
		db_config = read_db_config()
		conn = MySQLConnection(**db_config)

		cursor = conn.cursor()
		cursor.execute(query, args)

		if cursor.lastrowid:
			print('done')
		else:
			print('last insert id not found')

		conn.commit()
	except Error as error:
		print(error)

	finally:
		cursor.close()
		conn.close()
